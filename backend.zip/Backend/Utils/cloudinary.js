const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "nukenill",
  api_key: "136929179243195",
  api_secret: "EKtb8yVkF5oIoa9VlOcCIGixtgc",
});

module.exports = cloudinary;
