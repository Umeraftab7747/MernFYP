const mongoose = require("mongoose");

const RatingSchema = mongoose.Schema({
  ServiceId: String,
  UserName: String,
  UserEmail: String,
  ServiceName: String,
  Rating: String,
  Date: String,
  Message: String,
});

exports.RatingDb = mongoose.model("RatingDb", RatingSchema);
