const mongoose = require("mongoose");

const BookingSchema = mongoose.Schema({
  UserEmail: String,
  UserName: String,
  ServiceProviderEmail: String,
  ServiceId: String,
  ServiceName: String,
  ServiceType: String,
  Date: String,
  Dispute: String,
  Disputedby: String,
  Message: String,
  AdminAction: Boolean,
  Complete: Boolean,
  PhoneNo: String,
  discription: String,
  BookingDay: String,
  ServiceproviderAprove: Boolean,
  day: String,
  time: String,
});

exports.BookingDb = mongoose.model("BookingDb", BookingSchema);
