const mongoose = require("mongoose");

const ServiceProviderSchema = mongoose.Schema({
  Firstname: String,
  Companyname: String,
  Password: String,
  Email: {
    type: String,
    unique: true,
  },
  Cnic: String,
  Phone: String,
  isVerified: Boolean,
});

exports.ServiceProvider = mongoose.model(
  "ServiceProvider",
  ServiceProviderSchema
);
