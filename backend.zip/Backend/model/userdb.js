const mongoose = require("mongoose");

const UserSchema = mongoose.Schema({
  Name: String,
  Password: String,
  Email: {
    type: String,
    unique: true,
  },
  Cnic: String,
  Phone: String,
  EmailToken: String,
  isVerified: Boolean,
});

exports.Userdb = mongoose.model("User", UserSchema);
