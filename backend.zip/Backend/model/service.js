const mongoose = require("mongoose");

const ServiceSchema = mongoose.Schema({
  Email: String,
  ServiceName: String,
  ServicePrice: String,
  ServiceType: String,
  discription: String,
  Avatar: String,
  test: String,
  isVerified: Boolean,
  Message: String,
  ImageUrl: String,
  Startinghour: String,
  EndingHour: String,
});

exports.Servicedb = mongoose.model("Services", ServiceSchema);
