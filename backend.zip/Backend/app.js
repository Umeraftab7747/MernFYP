const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const app = express();
const morgan = require("morgan");
const mongoose = require("mongoose");
const cors = require("cors");

const UsersRouter = require("./routes/users");
const ServiceRouter = require("./routes/servicesproviders");
const AdminRouter = require("./routes/admins");
const Service = require("./routes/services");
const bookingRoute = require("./routes/booking");
const ratingRoute = require("./routes/rating");

app.use(cors());
app.use(cors({ origin: true, credentials: true }));
app.options("*", cors());
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(morgan("tiny"));

// routes
app.use("/users", UsersRouter);
app.use("/service-provider", ServiceRouter);
app.use("/admin", AdminRouter);
app.use("/service", Service);
app.use("/booking", bookingRoute);
app.use("/rating", ratingRoute);

//db
mongoose
  .connect("mongodb://localhost/Market", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("DATABASE IS CONNECTED");
  })
  .catch((err) => console.log(err));

// listen

app.listen(3000, () => {
  console.log("server is running on localhost:3000");
});
