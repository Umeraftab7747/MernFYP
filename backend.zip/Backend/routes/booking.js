const router = require("express").Router();
const { Servicedb } = require("../model/service");
const { BookingDb } = require("../model/bookingDb");

// get the data
router.get("/alldata", (req, res) => {
  Servicedb.find({
    isVerified: true,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// Book
router.post("/book", (req, res) => {
  // time
  const event = new Date();
  const Today = event.toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  // time

  const Newbooking = new BookingDb({
    UserEmail: req.body.UserEmail,
    UserName: req.body.UserName,
    ServiceProviderEmail: req.body.ServiceProviderEmail,
    ServiceId: req.body.ServiceId,
    ServiceName: req.body.ServiceName,
    ServiceType: req.body.ServiceType,
    Date: Today,
    Dispute: false,
    Disputedby: req.body.Disputedby,
    Message: null,
    AdminAction: false,
    Complete: false,
    PhoneNo: req.body.PhoneNo,
    discription: req.body.discription,
    BookingDay: req.body.BookingDay,
    ServiceproviderAprove: false,
    day: req.body.day,
    time: req.body.time,
  });
  Newbooking.save()
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: "200",
          user,
          msg: "Service Booked",
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// UserBOOKING
// get the data
router.post("/userbooking", (req, res) => {
  console.log(req.body.Email);
  BookingDb.find({
    UserEmail: req.body.Email,
    Dispute: false,
    Complete: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// get Completed the data
router.post("/Completeuserbooking", (req, res) => {
  console.log(req.body.Email);
  BookingDb.find({
    UserEmail: req.body.Email,
    Dispute: false,
    Complete: true,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// get User Disputed the data
router.post("/Disputeuserbooking", (req, res) => {
  console.log(req.body.Email);
  BookingDb.find({
    UserEmail: req.body.Email,
    Dispute: true,
    Complete: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});
// get Admin Disputed the data
router.get("/AdminDisputes", (req, res) => {
  BookingDb.find({
    Dispute: true,
    Complete: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});
// get Admin see all Completed the data
router.get("/AdminBooking", (req, res) => {
  BookingDb.find({
    Dispute: false,
    Complete: true,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// service Provider
// get the data
router.post("/Serviceproviderbooking", (req, res) => {
  console.log(req.body.Email);
  BookingDb.find({
    ServiceProviderEmail: req.body.Email,
    Dispute: false,
    Complete: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// service Provider Dispute
router.post("/Dispute", (req, res) => {
  BookingDb.findOneAndUpdate(
    {
      _id: req.body.id,
    },
    {
      Dispute: true,
      Disputedby: req.body.Disputedby,
      Message: req.body.Message,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// service Completed
router.post("/Completed", (req, res) => {
  BookingDb.findOneAndUpdate(
    {
      _id: req.body.id,
    },
    {
      Complete: true,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
          msg: "Service Marked Completed",
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// service Provider Dispute
router.post("/AdminDelet", (req, res) => {
  BookingDb.findOneAndDelete({
    _id: req.body.id,
  })
    .then((res) => {
      if (res) {
        res.status(200).json({
          status: 200,
          user,
          msg: "deleted Sucessfully",
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// find and delet
router.post("/deleteBooking", async (req, res) => {
  const data = req.body;
  try {
    const User = await BookingDb.findOneAndDelete({ _id: data._id });

    if (!User) {
      res.status(404).json({
        msg: "Unable to Delete",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Deleting Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});

// BOOKING DETAILS
router.post("/SPEICIFEDBOOKING", (req, res) => {
  BookingDb.findOne({ _id: req.body.id })
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

router.post("/BookingUpdate", (req, res) => {
  BookingDb.findOneAndUpdate(
    { _id: req.body.id },
    {
      UserName: req.body.Name,
      BookingDay: req.body.BookingDay,
      PhoneNo: req.body.Phone,
      discription: req.body.discription,
      day: req.body.day,
      time: req.body.time,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

// BOOKING DETAILS
router.post("/BOOKINGREQUEST", (req, res) => {
  BookingDb.find({
    ServiceProviderEmail: req.body.Email,
    ServiceproviderAprove: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});
// BOOKING DETAILS
router.post("/AceptBooking", (req, res) => {
  BookingDb.findOneAndUpdate(
    {
      _id: req.body._id,
    },
    {
      ServiceproviderAprove: true,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});
// BOOKING DETAILS
router.post("/RejectBooking", (req, res) => {
  BookingDb.findOneAndDelete({
    _id: req.body._id,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

// get the data
router.post("/Bookingtime", (req, res) => {
  console.log(req.body.Email);
  BookingDb.find({
    ServiceId: req.body.id,
    Complete: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

module.exports = router;
