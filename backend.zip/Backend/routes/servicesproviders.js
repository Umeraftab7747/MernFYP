const express = require("express");
const router = express.Router();
const { ServiceProvider } = require("../model/serviceprovider");
const { Servicedb } = require("../model/service");

var API_KEY = "38842e84bc1d61f283d4039489397f30-b6d086a8-e0166ebb";
var DOMAIN = "sandbox05dadf30c2cb45fbaf843df8750e76d8.mailgun.org";
var mailgun = require("mailgun-js")({ apiKey: API_KEY, domain: DOMAIN });

router.get("/", (req, res) => {
  ServiceProvider.find({})
    .then((user) => {
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({
          msg: "No User Found",
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        msg: "ERROR",
        error: error,
      });
    });
});

// USER Signup ADDED
router.post("/signup", (req, res) => {
  const data = req.body;
  console.log(data);
  const NewUser = new ServiceProvider({
    Firstname: data.Firstname,
    Companyname: data.Companyname,
    Password: data.Password,
    Email: data.Email,
    Cnic: data.Cnic,
    Phone: data.Phone,
    isVerified: false,
  });
  NewUser.save()
    .then((user) => {
      res.status(200).json({
        user,
        msg: "User will be verified by Admin",
        status: 200,
      });
    })
    .catch((err) => {
      res.status(500).json({
        error: err.message,
        sucess: false,
        message: "Email Already Registered",
        status: 500,
      });
    });
});

// USER Signin ADDED
router.post("/signin", (req, res) => {
  ServiceProvider.findOne({
    Email: req.body.email,
    Password: req.body.password,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          sucess: true,
          msg: "User Login",
          status: 200,
        });
      }

      if (!user) {
        res
          .status(500)
          .json({ status: "500", msg: "Check Email or Password Again" });
      }
    })
    .catch((error) => {
      res.status(404).json({
        status: "404",
        msg: error,
      });
    });
});

// USER PsswordReset Route ADDED
router.post("/password", (req, res) => {
  ServiceProvider.findOne({ Email: req.body.Email })
    .then((user) => {
      console.log(user);
      if (user) {
        //   Passowrd Reset

        var data = {
          to: user.Email,
          from: "noreply@securityService.com",
          subject: "Hi there",
          text: "Reset your Password",
          html: `<h1>HELLO!</h1>
  <p>kindly Reset your password through given link</p>
  <a href="http://localhost:3000/service-provider/Password-reset?token=${user.Email}">Reset Password</a>
  
  `,
        };
        mailgun.messages().send(data, (error, body) => {
          console.log(body);
        });

        //   Passowrd Reset

        res.status(200).json({
          sucess: true,
          msg: "Password Reset",
          status: 200,
        });
      } else {
        res.status(500).json({ msg: "User not found", status: 500 });
      }
    })
    .catch((error) => {
      res.status(404).json({ msg: error, status: 404 });
    });
});

// reset
// Password Reset Route2
router.post("/Password-reset/:token", async (req, res) => {
  console.log(req.params.token, req.body.Password);
  // res.render("done.html");
  try {
    const User = await ServiceProvider.findOneAndUpdate(
      { Email: req.params.token },
      { Password: req.body.Password }
    );
    if (!User) {
      res.send("not verified");
    } else {
      res.render("done.html");
    }
    res.render("done.html");
  } catch (error) {
    res.render("about.html", { token: req.params.token });
  }
});

// Password Reset Route2
router.get("/Password-reset", async (req, res) => {
  const data = req.query;
  res.render("serivceprovider.html", { token: data.token });
});

// get ALl services
router.get("/services/:Email", (req, res) => {
  Servicedb.find({
    isVerified: false,
    Email: req.params.Email,
  })
    .then((user) => {
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({
          msg: "No User Found",
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        msg: "ERROR",
        error: error,
      });
    });
});
// get ALl verfied services
router.get("/verifiedservices/:Email", (req, res) => {
  Servicedb.find({
    isVerified: true,
    Email: req.params.Email,
  })
    .then((user) => {
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({
          msg: "No User Found",
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        msg: "ERROR",
        error: error,
      });
    });
});

// SSP Details
router.post("/ServiceProviderData", (req, res) => {
  ServiceProvider.find({ Email: req.body.Email })
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});
// SSP Details UPDATE
router.post("/SSPUpdate", (req, res) => {
  ServiceProvider.findOneAndUpdate(
    { Email: req.body.Email },
    {
      Firstname: req.body.Name,
      Email: req.body.Email,
      Cnic: req.body.Cnic,
      Phone: req.body.Phone,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

module.exports = router;
