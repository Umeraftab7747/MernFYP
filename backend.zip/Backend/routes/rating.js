const router = require("express").Router();
const { RatingDb } = require("../model/RatingDb");

// Book
router.post("/rateService", (req, res) => {
  // time
  const event = new Date();
  const Today = event.toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  // time

  const NewRating = new RatingDb({
    ServiceId: req.body.Sid,
    UserName: req.body.UserName,
    UserEmail: req.body.UserEmail,
    ServiceName: req.body.ServiceName,
    Rating: req.body.Rating,
    Date: Today,
    Message: req.body.Message,
  });
  NewRating.save()
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: "200",
          user,
          msg: "Service Rated!",
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});
// GetRating
router.post("/rating", (req, res) => {
  RatingDb.find({ ServiceId: req.body.id })
    .then((user) => {
      if (user) {
        res.status(200).json({
          sucess: true,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

module.exports = router;
