const express = require("express");
const router = express.Router();
const { ServiceProvider } = require("../model/serviceprovider");

// to get all service provider data
router.get("/", (req, res) => {
  ServiceProvider.find({})
    .then((user) => {
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({
          msg: "No User Found",
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        msg: "ERROR",
        error: error,
      });
    });
});

// non-verfied data
router.get("/non-verify", (req, res) => {
  ServiceProvider.find({ isVerified: false })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      } else {
        res.status(404).json({
          msg: "No User Found",
          status: 404,
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        status: 505,
        msg: "ERROR",
        error: error,
      });
    });
});

// ALLverfied USERS
router.get("/ALLverify", (req, res) => {
  ServiceProvider.find({ isVerified: true })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      } else {
        res.status(404).json({
          msg: "No User Found",
          status: 404,
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        status: 505,
        msg: "ERROR",
        error: error,
      });
    });
});

// verify by id link
router.post("/verify", async (req, res) => {
  const data = req.body;
  try {
    const User = await ServiceProvider.findOneAndUpdate(
      { Email: data.Email },
      { isVerified: true }
    );

    if (!User) {
      res.status(404).json({
        msg: "Unable to verify",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Verifcation Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});

// find and delet
router.post("/delete", async (req, res) => {
  const data = req.body;
  try {
    const User = await ServiceProvider.findOneAndDelete({ Email: data.Email });

    if (!User) {
      res.status(404).json({
        msg: "Unable to Delete",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Deleting Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});
// find and delet
router.post("/Block", async (req, res) => {
  const data = req.body;
  try {
    const User = await ServiceProvider.findOneAndUpdate(
      { Email: data.Email },
      { isVerified: false }
    );

    if (!User) {
      res.status(404).json({
        msg: "Unable to Delete",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Deleting Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
