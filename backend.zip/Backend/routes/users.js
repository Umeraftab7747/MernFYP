const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const { Userdb } = require("../model/userdb");
var nodemailer = require("nodemailer");
var SendGridTransport = require("nodemailer-sendgrid-transport");
// const { ServiceProvider } = require("../model/serviceprovider");
const { Servicedb } = require("../model/service");

var API_KEY = "38842e84bc1d61f283d4039489397f30-b6d086a8-e0166ebb";
var DOMAIN = "sandbox05dadf30c2cb45fbaf843df8750e76d8.mailgun.org";
var mailgun = require("mailgun-js")({ apiKey: API_KEY, domain: DOMAIN });

router.get("/", (req, res) => {
  Userdb.find({})
    .then((user) => {
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({
          msg: "No User Found",
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        msg: "ERROR",
        error: error,
      });
    });
});

// USER Signup ADDED
router.post("/signup", (req, res) => {
  const data = req.body;
  const NewUser = new Userdb({
    Name: data.Name,
    Password: data.Password,
    Email: data.Email,
    Cnic: data.Cnic,
    Phone: data.Phone,

    EmailToken: crypto.randomBytes(64).toString("hex"),
    isVerified: false,
  });
  NewUser.save()
    .then((user) => {
      var data = {
        to: user.Email,
        from: "noreply@securityService.com",
        subject: "Hi there",
        text: "Verify your Email",
        html: `<h1>HELLO!</h1>
    <p>kindly Verify your Email through given link</p>
    <a href="http://localhost:3000/users/verify-email?token=${user.EmailToken}">Verfiy your account</a>
    
    `,
      };
      mailgun.messages().send(data, (error, body) => {
        console.log(body);
      });

      //   email verification

      res.status(200).json({
        user,
        msg: "User Account Created verify Mail and Login",
        status: "200",
      });
    })
    .catch((err) => {
      res.status(500).json({
        error: err.message,
        status: 500,
      });
    });
});

// email verification route
router.get("/verify-email", async (req, res) => {
  try {
    const User = await Userdb.findOne({ EmailToken: req.query.token });
    if (!User) {
      res.status(404).json({
        msg: "TOKEN IS INVALID NOW",
      });
    }

    User.EmailToken = null;
    User.isVerified = true;
    await User.save();
    res.send("USER VERIFIED");
  } catch (error) {
    console.log(error);
  }
});

// USER Signin ADDED
router.post("/signin", (req, res) => {
  Userdb.findOne({ Email: req.body.email, Password: req.body.password })
    .then((user) => {
      if (user) {
        if (user.isVerified) {
          res.status(200).json({
            sucess: true,
            msg: "User Login",
          });
        } else {
          res.status(505).json({
            msg: "verfiy your account to Signin",
          });
        }
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

// USER PsswordReset Route ADDED
router.post("/password", (req, res) => {
  const data = req.body;

  Userdb.findOne({ Email: req.body.Email })
    .then((user) => {
      if (user) {
        //   Passowrd Reset

        var data = {
          to: user.Email,
          from: "noreply@securityService.com",
          subject: "Hi there",
          text: "Reset your Password",
          html: `<h1>HELLO!</h1>
<p>kindly Reset your password through given link</p>
<a href="http://localhost:3000/users/Password-reset?token=${user.Email}">Reset Password</a>

`,
        };
        mailgun.messages().send(data, (error, body) => {
          console.log(body);
        });

        //   Passowrd Reset

        res.status(200).json({
          sucess: true,
          msg: "Password Reset",
          status: 200,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message, status: 404 });
    });
});

// Password Reset Route2
router.post("/Password-reset/:token", async (req, res) => {
  console.log(req.params.token, req.body.Password);
  // res.render("done.html");
  try {
    const User = await Userdb.findOneAndUpdate(
      { Email: req.params.token },

      { Password: req.body.Password }
    );
    if (!User) {
      res.send("not verified");
    } else {
      res.render("done.html");
    }
    res.render("done.html");
  } catch (error) {
    res.render("about.html", { token: req.params.token });
  }
});

// Password Reset Route2
router.get("/Password-reset", async (req, res) => {
  const data = req.query;
  res.render("about.html", { token: data.token });
});

// verfied data
router.get("/services", (req, res) => {
  Servicedb.find({ isVerified: true })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      } else {
        res.status(404).json({
          msg: "No User Found",
          status: 404,
        });
      }
    })
    .catch((error) => {
      res.status(500).json({
        status: 505,
        msg: "ERROR",
        error: error,
      });
    });
});

// USER Details
router.post("/UserDetails", (req, res) => {
  Userdb.findOne({ Email: req.body.email })
    .then((user) => {
      if (user) {
        if (user.isVerified) {
          res.status(200).json({
            sucess: true,
            msg: "User Login",
            user,
          });
        } else {
          res.status(505).json({
            msg: "verfiy your account to Signin",
          });
        }
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});
// USER Details
router.post("/User", (req, res) => {
  Userdb.find({ Email: req.body.Email })
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});
// USER Details UPDATE
router.post("/UserUpdate", (req, res) => {
  Userdb.findOneAndUpdate(
    { Email: req.body.Email },
    {
      Name: req.body.Name,
      Email: req.body.Email,
      Cnic: req.body.Cnic,
      Phone: req.body.Phone,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          user,
        });
      } else {
        res.status(500).json({ status: "404", msg: "User not found" });
      }
    })
    .catch((error) => {
      res.status(404).json({ status: "404", msg: err.message });
    });
});

module.exports = router;
