const router = require("express").Router();
const cloudinary = require("../Utils/cloudinary");
const { Servicedb } = require("../model/service");

router.post("/", async (req, res) => {
  try {
    let user = new Servicedb({
      Email: req.body.Email,
      ServiceName: req.body.Name,
      ServicePrice: req.body.Price,
      ServiceType: req.body.ServiceType,
      discription: req.body.discription,
      isVerified: false,
      Message: "this will be done by Admin",
      test: req.body.test,
      ImageUrl: req.body.image,
      Startinghour: req.body.Startinghour,
      EndingHour: req.body.EndingHour,
    });

    await user.save();

    res.status(200).json({
      status: 200,
      user,
    });
  } catch (err) {
    console.log(err);
  }
});

// get the data
router.post("/Getdata", (req, res) => {
  Servicedb.find({
    Email: req.body.Email,
    isVerified: req.body.isVerified,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});
// get the data
router.get("/alldata", (req, res) => {
  Servicedb.find({
    isVerified: false,
  })
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// Update the data
router.post("/update", (req, res) => {
  Servicedb.findOneAndUpdate(
    { _id: req.body._id },
    {
      ServiceName: req.body.Name,
      ServiceType: req.body.ServiceType,
      discription: req.body.discription,
      Startinghour: req.body.Startinghour,
      EndingHour: req.body.EndingHour,
    }
  )
    .then((user) => {
      if (user) {
        res.status(200).json({
          status: 200,
          user,
        });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

// verify by id link
router.post("/Reject", async (req, res) => {
  const data = req.body;
  try {
    const User = await Servicedb.findOneAndUpdate(
      { _id: data._id },
      { isVerified: data.isVerified, Message: data.Message }
    );

    if (!User) {
      res.status(404).json({
        msg: "Unable to verify",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Verifcation Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});
// acept
router.post("/acept", async (req, res) => {
  const data = req.body;
  try {
    const User = await Servicedb.findOneAndUpdate(
      { _id: data._id },
      { isVerified: true, Message: data.Message }
    );

    if (!User) {
      res.status(404).json({
        msg: "Unable to verify",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "Verifcation Done",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});

// deleteService
router.post("/deletService", async (req, res) => {
  const data = req.body;
  try {
    const User = await Servicedb.findOneAndDelete({ _id: data._id });

    if (!User) {
      res.status(404).json({
        msg: "Unable to Delete",
        status: 404,
      });
    } else if (User) {
      res.status(200).json({
        msg: "DONE",
        status: 200,
      });
    }
  } catch (error) {
    console.log(error);
  }
});

// delete the image
router.delete("/:id", async (req, res) => {
  try {
    // Find user by id
    let user = await Servicedb.findById(req.params.id);
    // Delete image from cloudinary
    await cloudinary.uploader.destroy(user.cloudinary_id);
    // Delete user from db
    await user.remove();
    res.json(user);
  } catch (err) {
    console.log(err);
  }
});
module.exports = router;
